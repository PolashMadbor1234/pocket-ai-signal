# Polash Pro Trading Bot

বাংলা Telegram bot starter for selecting Quotex/Pocket Option, OTC/Real Market, and expiry duration.

## Included
- Broker selector: Quotex / Pocket Option
- Market selector: OTC / Real Market
- Expiry selector: 5 seconds / 15 seconds / 30 seconds / 1 minute
- Bengali Telegram menus
- Analysis profile: 1H trend, EMA 50/200, RSI threshold 52, Momentum period 4
- Safe default: `WAIT` until a verified market-data feed is connected

## Important limitations
This starter does **not** connect to broker accounts or place trades. It does not scrape private endpoints and never needs broker passwords. No Quotex/Pocket Option OTC or real-market data feed is connected yet. A permitted, reliable market-data provider or properly licensed feed must be integrated before live signals can be calculated.

Five- and fifteen-second signals require reliable second-level price data. The selected expiry is a user preference, not proof that data at that resolution is available. No signal can guarantee profit; test on demo data first.

## Run
1. Use Python 3.10 or newer.
2. Install dependencies: `pip install -r requirements.txt`
3. Set environment variable `TELEGRAM_BOT_TOKEN` to your BotFather token.
4. Run: `python main.py`

Do not commit your real token, `.env` file, passwords, or broker login details.

## Next step
Connect a permitted data source, normalize candle data separately for each instrument/feed, then implement and backtest EMA/RSI/Momentum and support/resistance logic. Until verified data is available, the bot intentionally returns `WAIT`.
